BATTERY ORACLE v0.5.0
Ghost Labs — Battery Fundamentals course tool
Parametric battery cell selector (student takeaway)
Dataset current as of: 2026-07-16

WHAT THIS IS
A single-file, offline web application. No installation, no internet,
no admin rights required. Works on Windows, macOS, and Linux in any
modern browser (Chrome, Edge, Firefox, Safari).

FOR STUDENTS
1. Copy this whole folder anywhere (laptop, USB stick, phone).
2. Double-click BatteryOracle.html. That's it.
Nothing is transmitted anywhere; the tool runs entirely in your browser.

FOLDER CONTENTS
  BatteryOracle.html   the entire application, including the cell dataset,
                       Ghost Labs logo, and embedded fonts
  datasheets/          put manufacturer datasheet PDFs here (optional)
  README.txt           this file

BRANDING / FONTS
Body and UI text: Montserrat (embedded, SIL Open Font License).
Display headings: styled for Ethnocentric. Ethnocentric is a commercial
font and is NOT embedded; on machines where Ghost Labs has it installed,
headings render in Ethnocentric automatically. Everywhere else they fall
back to Orbitron (embedded, SIL Open Font License), a visually similar
free techno face. If Ghost Labs obtains a webfont license for
Ethnocentric, add a matching @font-face rule at the top of the <style>
block with the licensed WOFF2 base64-embedded, and every heading will
pick it up with no other changes.

FOR INSTRUCTORS / MAINTAINERS

Adding or editing cells
  Open BatteryOracle.html in any text editor (Notepad++, VS Code, etc.)
  and find the block that starts:

      <script id="cell-data" type="application/json">

  Each cell is one JSON object; the field reference is in the comment
  directly above the block. Copy an existing entry of the same package
  type, edit its values, save, and reload the page in the browser.
  If you break the JSON (usually a missing or trailing comma), the app
  will tell you on screen instead of loading — fix and reload.

Attaching datasheets for offline use
  1. Drop the PDF into the datasheets/ folder, e.g. datasheets/l91.pdf
  2. In that cell's JSON entry, add:  "ds": "l91.pdf"
  A local "ds" file takes priority over the online "url" field.
  Ship the folder (not just the HTML file) so relative links work.

Versioning discipline
  When you change the dataset, update DATA_DATE (and APP_VERSION for
  functional changes) near the top of the <script> block at the bottom
  of BatteryOracle.html. Both are displayed in the header and footer so
  students always know which revision they are holding.

Distribution
  Zip this folder and hand it out however course materials normally
  travel: USB, email, shared drive, or alongside the course binder.
  The same folder can be uploaded as-is to any static web host
  (GitHub Pages, Cloudflare Pages, Netlify) if a hosted version is
  wanted later — no changes required.

DATA CAVEAT
Starter dataset specs were transcribed from published datasheets and
have NOT all been verified against current datasheet revisions.
Entries whose notes contain "VERIFY" are known-uncertain. Confirm every
figure against the manufacturer's current datasheet before relying on
it in a design. Pulse ratings in particular are not comparable across
manufacturers without their stated conditions.
